(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Exp1_atlas_1", frames: [[0,0,7587,3525],[0,3527,7587,3525]]},
		{name:"Exp1_atlas_2", frames: [[0,2618,2831,3184],[0,5804,4426,1520],[2833,2618,4426,1520],[2833,4140,4426,1520],[0,0,5679,2616],[4428,5662,2166,2215],[5681,0,2166,2215]]},
		{name:"Exp1_atlas_3", frames: [[2253,0,2166,2104],[6589,0,1404,2786],[4307,4215,1266,2703],[1682,6920,3668,657],[5575,4105,1434,1827],[0,4211,2166,2103],[3878,2106,1663,2107],[0,6316,1680,1838],[2168,2106,1708,2407],[5543,2788,2309,1315],[0,2105,2166,2104],[4421,0,2166,2104],[0,0,2251,2103],[2168,4515,2137,1878]]},
		{name:"Exp1_atlas_4", frames: [[3537,356,34,72],[3573,356,34,72],[3537,0,551,354],[0,0,3535,657],[2423,659,1455,966],[0,2037,2407,190],[0,2229,2407,190],[2409,2037,374,469],[0,2421,2407,190],[0,659,2421,687],[0,1348,2421,687],[0,2613,2407,190]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.ABC = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.blade11 = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.blade22 = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.blanket = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.couper1text = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.couper1text2 = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.dog1 = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.first = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.flame2 = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.flame = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.fourth = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.legande = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.m9as = function() {
	this.initialize(ss["Exp1_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.moelleepinierecopy = function() {
	this.initialize(ss["Exp1_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.moelleepinierecopy2 = function() {
	this.initialize(ss["Exp1_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.moelleepinierecopy02 = function() {
	this.initialize(ss["Exp1_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.muscle = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.nerf1pngcopy = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.nerf2pngcopy = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.second = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.suivant = function() {
	this.initialize(img.suivant);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19695,8261);


(lib.terminer = function() {
	this.initialize(img.terminer);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19695,8261);


(lib.text1 = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.text2 = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.text3 = function() {
	this.initialize(ss["Exp1_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.text4 = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.therd = function() {
	this.initialize(ss["Exp1_atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Untitled2 = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Untitled2pngcopy = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Untitled3 = function() {
	this.initialize(ss["Exp1_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Untitled3pngcopy = function() {
	this.initialize(ss["Exp1_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Untitled4 = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Untitled7 = function() {
	this.initialize(ss["Exp1_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Untitled8 = function() {
	this.initialize(img.Untitled8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,8405,6782);


(lib.Untitled8pngcopy = function() {
	this.initialize(img.Untitled8pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,8405,6782);


(lib.yellow = function() {
	this.initialize(ss["Exp1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.yellowpngcopy = function() {
	this.initialize(ss["Exp1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.blade22();
	this.instance.setTransform(-72.7,-86.4,0.0757,0.0757,-14.9917);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.7,-111.2,145.5,222.4);


(lib.textcouper2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.couper1text2();
	this.instance.setTransform(0,0,0.1365,0.136);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textcouper2, new cjs.Rectangle(0,0,500.6,89.4), null);


(lib.text2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,0,0.2018,0.2018);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2_1, new cjs.Rectangle(0,0,488.7,138.7), null);


(lib.text1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text1();
	this.instance.setTransform(0,0,0.2111,0.2111);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1_1, new cjs.Rectangle(0,0,511.1,145), null);


(lib.terminer_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.terminer();
	this.instance.setTransform(0,0,0.0092,0.0092);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.terminer_1, new cjs.Rectangle(0,0,182.1,76.4), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.flame();
	this.instance.setTransform(-63,-64.4,0.0582,0.0613);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-63,-64.4,126,128.9), null);


(lib.suivant_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.suivant();
	this.instance.setTransform(0,0,0.009,0.009);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.suivant_1, new cjs.Rectangle(0,0,177,74.3), null);


(lib.noir1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.nerf = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap26();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.nerf, new cjs.Rectangle(0,0,34,72), null);


(lib.moelle20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.moelleepinierecopy2();
	this.instance.setTransform(0,0,0.2188,0.2187);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.moelle20, new cjs.Rectangle(0,0,968.2,332.4), null);


(lib.mkas2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mkas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.m9as();
	this.instance.setTransform(0,115.75,0.0519,0.0519,-51.9449);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mkas, new cjs.Rectangle(0,0,220.9,217.7), null);


(lib.meolle2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.meolle1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.moelleepinierecopy();
	this.instance.setTransform(0,0,0.2188,0.2189);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.meolle1, new cjs.Rectangle(0,0,968.2,332.8), null);


(lib.mama3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.blade11();
	this.instance.setTransform(70.8,7.7,0.0733,0.0733,17.9673);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mama3, new cjs.Rectangle(7.8,7.7,160.89999999999998,226.10000000000002), null);


(lib.legandeText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.legande();
	this.instance.setTransform(0,0,0.4003,0.4003);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.legandeText, new cjs.Rectangle(0,0,665.8,843.5), null);


(lib.exitation11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Untitled3();
	this.instance.setTransform(0,0,0.0582,0.0582);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.exitation11, new cjs.Rectangle(0,0,126,128.9), null);


(lib.buttonmkas2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Untitled2pngcopy();
	this.instance.setTransform(0,0,0.0604,0.0604);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonmkas2, new cjs.Rectangle(0,0,130.9,127.2), null);


(lib.buttonmkas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Untitled2();
	this.instance.setTransform(0,0,0.0604,0.0604);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonmkas, new cjs.Rectangle(0,0,130.9,127.2), null);


(lib.ABC_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ABC();
	this.instance.setTransform(0,0,0.0582,0.0612);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ABC_1, new cjs.Rectangle(0,0,126,128.9), null);


(lib.text3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.mkas2 = new lib.mkas2();
	this.mkas2.name = "mkas2";
	this.mkas2.setTransform(109.5,355.15,1,1,0,0,0,109.5,108);

	this.meolle2 = new lib.meolle2();
	this.meolle2.name = "meolle2";
	this.meolle2.setTransform(647.85,220.4,1,1,0,0,0,484.1,166.4);

	this.instance = new lib.Untitled8pngcopy();
	this.instance.setTransform(1240.75,0,0.0622,0.0622);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1D1D1B").ss(1,1,1).p("EAAAB1DMAAAjqF");
	this.shape.setTransform(1240.75,750.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance},{t:this.meolle2},{t:this.mkas2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text3_1, new cjs.Rectangle(1239.8,0,524.1000000000001,1500.3), null);


(lib.mama4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.mama3();
	this.instance.setTransform(-6.3,0.05,0.6795,0.6795,159.5447,0,0,87.4,122.8);

	this.blade111 = new lib.Tween2();
	this.blade111.name = "blade111";
	this.blade111.setTransform(18.65,-0.75,0.6795,0.6795,159.5447,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.blade111},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mama4, new cjs.Rectangle(-84.4,-89.5,175.7,182.2), null);


(lib.mama2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.mkas = new lib.mkas();
	this.mkas.name = "mkas";
	this.mkas.setTransform(110.4,108.9,1,1,0,0,0,110.4,108.9);

	this.timeline.addTween(cjs.Tween.get(this.mkas).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mama2, new cjs.Rectangle(0,0,220.9,217.7), null);


// stage content:
(lib.Exp1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {mama2:3,mama4:5};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,2,3,5,7,10];
	// timeline functions:
	this.frame_0 = function() {
		
		// Assuming 'abcButton' and 'legandeText' are instance names in Animate
		var abcButton = this.abcButton; // Replace 'abcButton' with your actual instance name
		var legandeText = this.legandeText; // Replace 'legandeText' with your actual instance name
		
		legandeText.visible = false; // Initially hide 'LEGANDE'
		
		abcButton.addEventListener("click", toggleLegande);
		
		function toggleLegande() {
		    legandeText.visible = !legandeText.visible; // Toggle visibility of 'LEGANDE'
		}
		this.suivant1.visible = false;
		this.text2.visible = false;
		// 1-hadi bach d tki ela botona o yban m9as
		this.mkas.visible = false;
		
		// Add event listener to mama1
		this.buttonmkas.addEventListener("click", fl_TogglemkasVisibility.bind(this));
		
		// Event handler function to toggle mama2 visibility
		function fl_TogglemkasVisibility() {
		    // Toggle visibility of mama2
		    this.mkas.visible = !this.mkas.visible;
		
		    // Check if text1 is visible
		    if (this.text1.visible) {
		        // Hide text1 and show text2
		        this.text1.visible = false;
		        this.text2.visible = true;
				this.suivant1.visible = true;
		    }
		// hadi bach yb9a bayen fel frame kaml walakin khasek d 3mla fel west dyal had fonction bach madb9axi dban men lowel 
		this.addEventListener("tick", fl_TickHandler.bind(this));
		
		function fl_TickHandler() {
		    // Ensure text2, suivant1, and mkas remain visible throughout the frame
		    this.text2.visible = true;
		    this.suivant1.visible = true;
		    this.mkas.visible = true;
		}
		
		
		}
		
		// 2-dragin a roudaina 
		
		this.mkas.addEventListener("mousedown", (e) => {
		    this.offset = {x:this.mkas.x - e.stageX, y:this.mkas.y - e.stageY};
		});
		
		this.mkas.addEventListener("pressmove", (e) => {
		    this.mkas.x = e.stageX + this.offset.x;
		    this.mkas.y = e.stageY + this.offset.y;
		});
		
		this.mkas.addEventListener("pressup", (e) => {
		    // No action required on release, but you can add any necessary cleanup code here.
		});
		
		// Execute code on each frame
	}
	this.frame_2 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.suivant1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame()
		{
			this.gotoAndPlay(3);
		}
	}
	this.frame_3 = function() {
		this.stop();
		console.log("Animation stopped initially.");
		
		// Corrected logging to match instance names
		console.log("blade111:", this.mama2); 
		console.log("blade2:", this.mama4);
		
		// Check and add event listeners
		if (this.mama2) {
		    console.log("Adding event listener to blade111");
		    this.mama2.addEventListener("click", checkAndCut.bind(this));
		} else {
		    console.error("blade111 instance not found. Check instance name.");
		}
		
		if (this.mama4) {
		    console.log("Adding event listener to blade2");
		    this.mama4.addEventListener("click", cut.bind(this));
		} else {
		    console.error("Blade2 instance not found. Check instance name.");
		}
		
		// Hide the nerf instance initially
		this.nerf.visible = false;
		
		function checkAndCut() {
		    console.log("Check and cut function called.");
		
		    // Check if mama2 is above nerf
		    if (isAbove(this.mama2, this.nerf)) {
		        console.log("mama2 is above nerf, proceeding to cut.");
		
		        // Update the position of mama4 based on the current position of mama2
		        this.mama4.x = this.mama2.x;
		        this.mama4.y = this.mama2.y;
		
		        // Show the nerf instance
		        this.nerf.visible = true;
		
		        // Hide mama2 and show mama4
		        this.mama2.visible = false;
		        this.mama4.visible = true;
		
		        // Call the cut function to start the animation
		        this.play();
		    } else {
		        console.log("mama2 is not above nerf, nothing happens.");
		    }
		}
		
		function cut() {
		    console.log("Cut function called.");
		}
		
		function isAbove(instance1, instance2) {
		    // Calculate the bounding box of both instances
		    const bounds1 = instance1.getBounds();
		    const bounds2 = instance2.getBounds();
		
		    // Adjust the bounds to the current position
		    bounds1.x += instance1.x;
		    bounds1.y += instance1.y;
		    bounds2.x += instance2.x;
		    bounds2.y += instance2.y;
		
		    // Check if instance1 is above instance2
		    return bounds1.x < bounds2.x + bounds2.width &&
		           bounds1.x + bounds1.width > bounds2.x &&
		           bounds1.y < bounds2.y + bounds2.height &&
		           bounds1.y + bounds1.height > bounds2.y;
		}
		
		// Drag and drop functionality for mama2
		this.mama2.addEventListener("mousedown", (e) => {
		    this.offset = {x: this.mama2.x - e.stageX, y: this.mama2.y - e.stageY};
		});
		
		this.mama2.addEventListener("pressmove", (e) => {
		    this.mama2.x = e.stageX + this.offset.x;
		    this.mama2.y = e.stageY + this.offset.y;
		});
		
		this.mama2.addEventListener("pressup", (e) => {
		    // No action required on release, but you can add any necessary cleanup code here.
		});
		
		// Execute code on each frame
		createjs.Ticker.addEventListener("tick", handleTick);
		function handleTick(event) {
		    stage.update();
		}
	}
	this.frame_5 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
		
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.suivant2.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_2.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_2()
		{
			this.gotoAndPlay(7);
		}
	}
	this.frame_7 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
		
		this.feu23.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_3.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_3()
		{
			this.gotoAndPlay(9);
		}
	}
	this.frame_10 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.terminer.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_4.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_4()
		{
			this.gotoAndPlay(12);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2).call(this.frame_2).wait(1).call(this.frame_3).wait(2).call(this.frame_5).wait(2).call(this.frame_7).wait(3).call(this.frame_10).wait(1));

	// Actions
	this.suivant1 = new lib.suivant_1();
	this.suivant1.name = "suivant1";
	this.suivant1.setTransform(1778.5,1000.1,1,1,0,0,0,88.5,37.1);

	this.instance = new lib.first();
	this.instance.setTransform(1407,368,0.2108,0.2108);

	this.text1 = new lib.text1_1();
	this.text1.name = "text1";
	this.text1.setTransform(1662.5,527.5,1,1,0,0,0,255.5,72.5);

	this.text2 = new lib.text2_1();
	this.text2.name = "text2";
	this.text2.setTransform(1662.5,527.6,1.0458,1.0458,0,0,0,244.3,69.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text2},{t:this.text1},{t:this.instance},{t:this.suivant1}]}).to({state:[{t:this.text2},{t:this.text1},{t:this.instance},{t:this.suivant1}]},2).to({state:[]},1).wait(8));

	// LEGANDE
	this.legandeText = new lib.legandeText();
	this.legandeText.name = "legandeText";
	this.legandeText.setTransform(997.9,463.8,1,1,0,0,0,332.9,421.8);

	this.timeline.addTween(cjs.Tween.get(this.legandeText).wait(11));

	// ABC
	this.abcButton = new lib.ABC_1();
	this.abcButton.name = "abcButton";
	this.abcButton.setTransform(116,751.4,1,1,0,0,0,63,64.4);

	this.timeline.addTween(cjs.Tween.get(this.abcButton).wait(11));

	// Layer_25
	this.instance_1 = new lib.nerf2pngcopy();
	this.instance_1.setTransform(889,241,0.2575,0.2575);

	this.instance_2 = new lib.nerf1pngcopy();
	this.instance_2.setTransform(869,247,0.2627,0.2736);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(11));

	// Layer_26
	this.instance_3 = new lib.muscle();
	this.instance_3.setTransform(854.5,706.05,0.1517,0.2507,-12.446);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(11));

	// Layer_21
	this.text = new cjs.Text("1-Premiere expérience: ", "bold 50px 'Times New Roman'");
	this.text.lineHeight = 57;
	this.text.lineWidth = 508;
	this.text.parent = this;
	this.text.setTransform(1409.55,300.35);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(11));

	// Layer_16
	this.instance_4 = new lib.therd();
	this.instance_4.setTransform(1408,367,0.2108,0.2108);

	this.instance_5 = new lib.fourth();
	this.instance_5.setTransform(1408,367,0.2108,0.2108);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},6).to({state:[{t:this.instance_5}]},2).wait(3));

	// Layer_20
	this.terminer = new lib.terminer_1();
	this.terminer.name = "terminer";
	this.terminer.setTransform(1773,1001.2,1,1,0,0,0,91,38.2);
	this.terminer._off = true;

	this.timeline.addTween(cjs.Tween.get(this.terminer).wait(8).to({_off:false},0).wait(3));

	// Layer_18
	this.instance_6 = new lib.flame2();
	this.instance_6.setTransform(839,838,0.082,0.082);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(8).to({_off:false},0).wait(3));

	// suivant
	this.suivant2 = new lib.suivant_1();
	this.suivant2.name = "suivant2";
	this.suivant2.setTransform(1776.5,1000.1,1,1,0,0,0,88.5,37.1);
	this.suivant2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.suivant2).wait(5).to({_off:false},0).to({_off:true},1).wait(5));

	// Layer_13
	this.instance_7 = new lib.Untitled4();
	this.instance_7.setTransform(53,687,0.056,0.0613);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(11));

	// Layer_8
	this.instance_8 = new lib.flame();
	this.instance_8.setTransform(53,531,0.0582,0.0613);

	this.feu23 = new lib.Symbol1();
	this.feu23.name = "feu23";
	this.feu23.setTransform(116,595.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.instance_8}]},3).to({state:[{t:this.feu23}]},3).to({state:[{t:this.instance_8}]},2).wait(3));

	// Layer_12
	this.instance_9 = new lib.yellow();
	this.instance_9.setTransform(1403,438,0.0665,0.0505);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({_off:true},3).wait(8));

	// Layer_11
	this.instance_10 = new lib.Untitled7();
	this.instance_10.setTransform(1318,23,0.0639,0.0639);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(11));

	// Layer_10
	this.instance_11 = new lib.dog1();
	this.instance_11.setTransform(409,473,0.5191,0.5191);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(11));

	// Layer_9
	this.instance_12 = new lib.blanket();
	this.instance_12.setTransform(320,473,1.6967,1.3842);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(11));

	// Layer_4
	this.noir1 = new lib.noir1();
	this.noir1.name = "noir1";
	this.noir1.setTransform(1215.3,246.05,1,1,0,0,0,43,26);
	this.noir1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.noir1).wait(3).to({_off:false},0).wait(8));

	// Layer_3
	this.mama2 = new lib.mama2();
	this.mama2.name = "mama2";
	this.mama2.setTransform(266.65,358.15,1,1,0,0,0,110.4,108.9);

	this.mama4 = new lib.mama4("synched",0);
	this.mama4.name = "mama4";
	this.mama4.setTransform(256.55,373.85,1,1,14.9992);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mama2}]},3).to({state:[]},1).to({state:[{t:this.mama4}]},1).to({state:[]},1).wait(5));

	// Layer_6
	this.instance_13 = new lib.couper1text();
	this.instance_13.setTransform(1418,470,0.136,0.136);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(3).to({_off:false},0).to({_off:true},2).wait(6));

	// Layer_15
	this.instance_14 = new lib.yellowpngcopy();
	this.instance_14.setTransform(1405,444,0.0661,0.0335);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(3).to({_off:false},0).to({_off:true},2).wait(6));

	// Layer_19
	this.instance_15 = new lib.text4();
	this.instance_15.setTransform(1421,454,0.1986,0.1986);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(8).to({_off:false},0).wait(3));

	// Layer_17
	this.instance_16 = new lib.text3();
	this.instance_16.setTransform(1421,451,0.0789,0.0789);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(6).to({_off:false},0).to({_off:true},2).wait(3));

	// Layer_7
	this.instance_17 = new lib.second();
	this.instance_17.setTransform(1408,367,0.2108,0.2108);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(3).to({_off:false},0).to({_off:true},3).wait(5));

	// Layer_2
	this.instance_18 = new lib.Untitled8();
	this.instance_18.setTransform(1397,0,0.0623,0.0623);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1D1D1B").ss(1,1,1).p("AgJyQIATAAEgAJhUOMAAABB+EAAKBUPIgTAAMAAAhmf");
	this.shape.setTransform(1398,539.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DAFFFC").s().p("EgolAzQMAAAhmfMBRLAAAMAAABmfg");
	this.shape_1.setTransform(1658.75,750.225);

	this.textcouper2 = new lib.textcouper2();
	this.textcouper2.name = "textcouper2";
	this.textcouper2.setTransform(1662.3,514.25,1,1,0,0,0,250.3,44.6);

	this.textcouper3 = new lib.text3_1();
	this.textcouper3.name = "textcouper3";
	this.textcouper3.setTransform(1038.25,749.9,1,1,0,0,0,882,749.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_18}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_18}]},3).to({state:[{t:this.textcouper3},{t:this.textcouper2}]},2).to({state:[{t:this.textcouper3}]},1).to({state:[{t:this.textcouper3}]},2).wait(3));

	// Layer_14
	this.instance_19 = new lib.yellowpngcopy();
	this.instance_19.setTransform(1405,444,0.0661,0.0335);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(3).to({_off:false},0).wait(3).to({scaleY:0.054,y:437},0).wait(2).to({scaleY:0.0744,y:431},0).wait(3));

	// Layer_5
	this.nerf = new lib.nerf();
	this.nerf.name = "nerf";
	this.nerf.setTransform(1189,256,1,1,0,0,0,17,36);

	this.instance_20 = new lib.moelle20();
	this.instance_20.setTransform(804.1,220.2,1,1,0,0,0,484.1,166.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20},{t:this.nerf}]},3).to({state:[{t:this.instance_20},{t:this.nerf}]},3).to({state:[{t:this.instance_20},{t:this.nerf}]},2).wait(3));

	// Layer_1
	this.mkas = new lib.mkas();
	this.mkas.name = "mkas";
	this.mkas.setTransform(266.1,356.15,1,1,0,0,0,110.4,108.9);

	this.instance_21 = new lib.moelleepinierecopy02();
	this.instance_21.setTransform(320,54,0.2188,0.2188);

	this.instance_22 = new lib.exitation11();
	this.instance_22.setTransform(116,437.4,1,1,0,0,0,63,64.4);

	this.buttonmkas = new lib.buttonmkas();
	this.buttonmkas.name = "buttonmkas";
	this.buttonmkas.setTransform(118.5,290.6,1,1,0,0,0,65.5,63.6);

	this.instance_23 = new lib.Bitmap25();
	this.instance_23.setTransform(934,487);

	this.buttonmkas2 = new lib.buttonmkas2();
	this.buttonmkas2.name = "buttonmkas2";
	this.buttonmkas2.setTransform(118.5,290.6,1,1,0,0,0,65.5,63.6);

	this.meolle1 = new lib.meolle1();
	this.meolle1.name = "meolle1";
	this.meolle1.setTransform(804.1,220.4,1,1,0,0,0,484.1,166.4);

	this.instance_24 = new lib.Untitled3pngcopy();
	this.instance_24.setTransform(53,373,0.0582,0.0582);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.buttonmkas},{t:this.instance_22},{t:this.instance_21},{t:this.mkas}]}).to({state:[{t:this.instance_24},{t:this.meolle1},{t:this.buttonmkas2},{t:this.instance_23}]},3).to({state:[{t:this.instance_24},{t:this.meolle1},{t:this.buttonmkas2},{t:this.instance_23}]},3).to({state:[{t:this.instance_24},{t:this.meolle1},{t:this.buttonmkas2},{t:this.instance_23}]},2).wait(3));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(1013,539,907.3,960.8);
// library properties:
lib.properties = {
	id: '51F71CA2E1974D4089DC1873868AD4A2',
	width: 1920,
	height: 1080,
	fps: 24,
	color: "#DAFFFC",
	opacity: 1.00,
	manifest: [
		{src:"images/suivant.png", id:"suivant"},
		{src:"images/terminer.png", id:"terminer"},
		{src:"images/Untitled8.png", id:"Untitled8"},
		{src:"images/Untitled8pngcopy.png", id:"Untitled8pngcopy"},
		{src:"images/Exp1_atlas_1.png", id:"Exp1_atlas_1"},
		{src:"images/Exp1_atlas_2.png", id:"Exp1_atlas_2"},
		{src:"images/Exp1_atlas_3.png", id:"Exp1_atlas_3"},
		{src:"images/Exp1_atlas_4.png", id:"Exp1_atlas_4"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['51F71CA2E1974D4089DC1873868AD4A2'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;